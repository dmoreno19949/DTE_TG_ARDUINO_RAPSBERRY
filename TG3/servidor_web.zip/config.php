<?php
    // config.php
    // Credenciales
    $dbhost = "localhost";
    $dbuser = "iothings";
    $dbpass = "iothings";
    $dbname = "iothings";
    // Conexi�n con la base de datos
    $con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
?>
