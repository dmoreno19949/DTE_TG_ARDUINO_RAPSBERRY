<?php
header( "refresh:1;url=plot.php" );

	// iot.php
	// Importamos la configuración
	require("config.php");

	// Leemos los valores que nos llegan por GET

	// Esta es la instrucción para insertar los valores
	//$query = "INSERT INTO wp_valores(valor) VALUES('".$valor."')";
	
	// Create connection

	$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 


	$query = "SELECT *, DATE_FORMAT(hora,'%H:%m:%s') AS fechaFormato FROM wp_valores where ORIGEN='arduino' ORDER BY hora DESC LIMIT 120";
    
	$result = $conn->query($query);
	
	$labels = '';
	$datas = '';
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			//echo "id: " . $row["id"]. " - hora: " . $row["hora"]. " - origen: " . $row["origen"]. "  - valor: " . $row["valor"]. "<br>";
			$labels = $labels.'"'.$row['fechaFormato'].'",';
			$datas = $datas.'"'.$row['valor'].'",';
		}
	} else {
		echo "0 results";
	}



	
	
	$query = "SELECT *, DATE_FORMAT(hora,'%H:%m:%s') AS fechaFormato FROM wp_valores where ORIGEN='rasp' ORDER BY hora DESC LIMIT 120";
    
	$result = $conn->query($query);
	
	$labelsR = '';
	$datasR = '';
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			//echo "id: " . $row["id"]. " - hora: " . $row["hora"]. " - origen: " . $row["origen"]. "  - valor: " . $row["valor"]. "<br>";
			$labelsR = $labelsR.'"'.$row['fechaFormato'].'",';
			$datasR = $datasR.'"'.$row['valor'].'",';
		}
	} else {
		echo "0 results";
	}

	$conn->close();

	


?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DTE-P3</title>

<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/datepicker3.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body style="font-size:6px;">
	
		
	<div class="col-sm-12">			
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading" >ARDUINO </div>
					
					<div class="panel-body">
						<div class="canvas-wrapper">
							<canvas class="main-chart" id="line-chart" height="200" width="900"></canvas>
						</div>
					</div>
				</div>
			</div>
		</div><!--/.row-->
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default ">
					<div class="panel-heading" >RASPBERRY </div>
					<div class="panel-body">
						<div class="canvas-wrapper">
							<canvas class="main-chart" id="line-chart1" height="200" width="900"></canvas>
						</div>
					</div>
				</div>
			</div>
		</div><!--/.row-->
		
	
											
	</div>	<!--/.main-->
	  

	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script>
	</script>
	<script>
	var randomScalingFactor = function(){ return Math.round(Math.random()*1000)};
	
		var lineChartData = {
				labels : [<?php print $labels;?>],
				datasets : [
					{
						label: "Arduino",
						fillColor : "rgba(0,220,220,0.2)",
						strokeColor : "rgba(0,220,220,1)",
						pointColor : "rgba(0,220,220,1)",
						pointStrokeColor : "#fff",
						pointHighlightFill : "#fff",
						pointHighlightStroke : "rgba(0,220,220,1)",
						data : [<?php print $datas;?>]
					}
				]

			}
			
		var lineChartData1 = {
				labels : [<?php print $labelsR;?>],
				datasets : [
					{
						label: "RASPBERRY",
						fillColor : "rgba(220,0,220,0.2)",
						strokeColor : "rgba(220,0,220,1)",
						pointColor : "rgba(220,0,220,1)",
						pointStrokeColor : "#fff",
						pointHighlightFill : "#fff",
						pointHighlightStroke : "rgba(220,0,220,1)",
						data : [<?php print $datasR;?>]
					}
				]

			}


		window.onload = function(){
			var chart1 = document.getElementById("line-chart").getContext("2d");
			window.myLine = new Chart(chart1).Line(lineChartData, {
				responsive: true,
				 animation: false
			});
			var chart2 = document.getElementById("line-chart1").getContext("2d");
			window.myLine2 = new Chart(chart2).Line(lineChartData1, {
				responsive: true,
				 animation: false
			});
			
			
		};
		
		
		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
