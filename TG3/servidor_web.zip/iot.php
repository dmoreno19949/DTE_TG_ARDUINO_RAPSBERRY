<?php
	// iot.php
	// Importamos la configuraci�n
	require("config.php");

	// Leemos los valores que nos llegan por GET
	$valor = mysqli_real_escape_string($con, $_GET['valor']);
	$origen = mysqli_real_escape_string($con, $_GET['origen']);
    
	// Esta es la instrucci�n para insertar los valores
	//$query = "INSERT INTO wp_valores(valor) VALUES('".$valor."')";
	$query = "INSERT INTO wp_valores(origen, valor) VALUES('".$origen."','".$valor."')";
    
	// Ejecutamos la instrucci�n
	mysqli_query($con, $query);
	
	mysqli_close($con);
	print "Recibido origen:".$origen." valor:".$valor;
?>
